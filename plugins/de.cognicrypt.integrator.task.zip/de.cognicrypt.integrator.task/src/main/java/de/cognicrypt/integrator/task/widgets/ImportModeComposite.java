package de.cognicrypt.integrator.task.widgets;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;

import de.cognicrypt.core.Constants;
import de.cognicrypt.integrator.task.wizard.TaskIntegratorWizardImportPage;
import de.cognicrypt.integrator.task.wizard.TaskIntegratorWizardPage;

public class ImportModeComposite extends Composite {

	//private final FileBrowserComposite importFile;
	
	public ImportModeComposite(final Composite parent, final int style,
			final TaskIntegratorWizardImportPage wizardPage) {
		super(parent, style);
		
		setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		setLayout(new GridLayout(1, false));

		final Button btnImportMode = new Button(this, SWT.CHECK);
		btnImportMode.setText("Import Mode");
		btnImportMode.setSelection(true);
		
		/*importFile = new FileBrowserComposite((Composite) this, SWT.NONE,
				Constants.WIDGET_DATA_LOCATION_OF_JSON_FILE, new String[] { "*.json" },
				"Select JSON file that contains the high-level questions", wizardPage);
		importFile.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));*/
	}

}
