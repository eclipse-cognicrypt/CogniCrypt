package de.cognicrypt.integrator.task.wizard;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;

import de.cognicrypt.integrator.task.widgets.ImportModeComposite;
import de.cognicrypt.integrator.task.widgets.TaskInformationComposite;

public class TaskIntegratorWizardImportPage extends WizardPage {

	private ImportModeComposite importModeComposite;
	
	public  TaskIntegratorWizardImportPage(final String name, final String title, final String description) {
		super(name);
		setTitle(title);
		setDescription(description);
		setPageComplete(true);
	}

	@Override
	public void createControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		setControl(container);
		
		importModeComposite = new ImportModeComposite(container, SWT.NONE, this);

		container.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		container.setLayout(new GridLayout(1, false));
	}

}
